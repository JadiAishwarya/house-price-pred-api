import numpy as np
import joblib
from flask import Flask, request, jsonify, render_template

app = Flask(__name__)

# Load the trained model
model = joblib.load("house_price_model.pkl")

@app.route("/")
def home():
    return "<h2>House Price Prediction API is running!</h2><p>Use the /predict endpoint with JSON input to get predictions.</p>"

@app.route("/predict", methods=["POST"])
def predict():
    try:
        data = request.get_json()

        # Expecting features as a list (e.g., [bedrooms, bathrooms, sqft, ...])
        features = np.array(data["features"]).reshape(1, -1)
        prediction = model.predict(features)

        return jsonify({
            "prediction": prediction[0]
        })

    except Exception as e:
        return jsonify({
            "error": str(e)
        })

if __name__ == "__main__":
    app.run(debug=True)
